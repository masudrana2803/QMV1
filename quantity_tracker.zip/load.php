<?php
header("Content-Type: application/json");
$conn = new mysqli("localhost", "dbuser", "dbpass", "quantity_tracker");
$username = $_GET["user"];
$role = $_GET["role"];
if ($role === "admin") {
    $result = $conn->query("SELECT * FROM records");
} else {
    $result = $conn->query("SELECT * FROM records WHERE owner='$username'");
}
$data = [];
while ($row = $result->fetch_assoc()) { $data[] = $row; }
echo json_encode($data);
?>