CREATE DATABASE quantity_tracker;
USE quantity_tracker;
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE,
    password VARCHAR(255),
    role ENUM('user','admin') DEFAULT 'user'
);
CREATE TABLE records (
    id INT AUTO_INCREMENT PRIMARY KEY,
    record_id VARCHAR(50),
    type VARCHAR(100),
    brand VARCHAR(100),
    qty INT,
    date DATE,
    person VARCHAR(200),
    owner VARCHAR(50)
);
INSERT INTO users (username, password, role) VALUES
('user1', 'pass1', 'user'),
('user2', 'pass2', 'user'),
('masud', 'rana123', 'user'),
('masudrana', 'masud122803', 'admin');