<?php
header("Content-Type: application/json");
$conn = new mysqli("localhost", "dbuser", "dbpass", "quantity_tracker");
$id = (int)$_GET["id"];
$sql = "DELETE FROM records WHERE id=$id";
if ($conn->query($sql)) { echo json_encode(["success" => true]); } else { echo json_encode(["success" => false]); }
?>