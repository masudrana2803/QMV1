<?php
header("Content-Type: application/json");
$conn = new mysqli("localhost", "dbuser", "dbpass", "quantity_tracker");
$data = json_decode(file_get_contents("php://input"), true);
$id = $conn->real_escape_string($data["id"]);
$type = $conn->real_escape_string($data["type"]);
$brand = $conn->real_escape_string($data["brand"]);
$qty = (int)$data["qty"];
$date = $conn->real_escape_string($data["date"]);
$person = $conn->real_escape_string($data["person"]);
$owner = $conn->real_escape_string($data["owner"]);
$sql = "INSERT INTO records (record_id, type, brand, qty, date, person, owner) VALUES ('$id', '$type', '$brand', $qty, '$date', '$person', '$owner')";
if ($conn->query($sql)) { echo json_encode(["success" => true]); } else { echo json_encode(["success" => false, "error" => $conn->error]); }
?>