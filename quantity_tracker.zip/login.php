<?php
header("Content-Type: application/json");
$conn = new mysqli("localhost", "dbuser", "dbpass", "quantity_tracker");
$data = json_decode(file_get_contents("php://input"), true);
$username = $conn->real_escape_string($data["username"]);
$password = $conn->real_escape_string($data["password"]);
$result = $conn->query("SELECT * FROM users WHERE username='$username' AND password='$password'");
if ($row = $result->fetch_assoc()) {
    echo json_encode([ "success" => true, "user" => $row["username"], "role" => $row["role"] ]);
} else {
    echo json_encode(["success" => false]);
} ?>